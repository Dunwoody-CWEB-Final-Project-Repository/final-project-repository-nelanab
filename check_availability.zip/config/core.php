<?php
    // set your default time-zone
    date_default_timezone_set('America/Los_Angeles');
?>